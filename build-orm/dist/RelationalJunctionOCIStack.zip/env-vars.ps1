# to source this file run:
# Set-ExecutionPolicy Bypass -Scope Process -Force; .\env-vars.ps1

$env:TF_VAR_compartment_ocid="ocid1.compartment.oc1..aaaaaaaabun77s3z43l6axwmosswpkmxqzios63kret66qzryu4qs4byxebq"

# Required for the OCI Provider
$env:TF_VAR_tenancy_ocid="ocid1.tenancy.oc1..aaaaaaaaak3kfv3mstm3pd74u736boff5suiknqu2khdmsxkgmzou3cqjyvq"
$env:TF_VAR_user_ocid="ocid1.user.oc1..aaaaaaaard3xrfphv5gylm5ol66emqo7dqlrvv6uqnlhjz6k733slnucatya"

$env:TF_VAR_fingerprint = "b2:87:13:05:e9:77:bf:8b:74:0e:3d:0a:44:71:d9:a3	"
$env:TF_VAR_private_key_path="C:/Users/william/.oci/oci_api_key.pem"
$env:TF_VAR_region="us-ashburn-1"
# Keys used to SSH to OCI VMs
$env:TF_VAR_ssh_public_key = Get-Content (Resolve-Path "~/.ssh/WDTF.pub") -Raw -Encoding ASCII
$env:TF_VAR_ssh_private_key = Get-Content (Resolve-Path "~/.ssh/WDTF") -Raw -Encoding ASCII
#$env:TF_VAR_analytics_instance_idcs_access_token = Get-Content (Resolve-Path "~/.ssh/tokens.tok") -Raw -Encoding ASCII