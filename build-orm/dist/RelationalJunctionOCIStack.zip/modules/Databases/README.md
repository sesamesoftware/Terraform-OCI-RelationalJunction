# Terraform-Modules

Database Modules For building databases on OCI Platform
